public interface vendible {public interface Vendible {
    double calcularPrecioVenta();
}

}
