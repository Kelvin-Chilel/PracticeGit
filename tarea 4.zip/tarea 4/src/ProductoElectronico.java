public class ProductoElectronico {
    public class ProductoElectronico extends Producto implements Vendible {
        private int garantiaMeses;

        public ProductoElectronico(String nombre, String descripcion, String categoria, double precio, String urlFoto, int garantiaMeses) {
            super(nombre, descripcion, categoria, precio, urlFoto);
            this.garantiaMeses = garantiaMeses;
            public class ProductoElectronico extends Producto implements Vendible {
                private int garantiaMeses;

                public ProductoElectronico(String nombre, String descripcion, String categoria, double precio, String urlFoto, int garantiaMeses) {
                    super(nombre, descripcion, categoria, precio, urlFoto);
                    this.garantiaMeses = garantiaMeses;
                    public class ProductoElectronico extends Producto implements Vendible {
                        private int garantiaMeses;

                        public ProductoElectronico(String nombre, String descripcion, String categoria, double precio, String urlFoto, int garantiaMeses) {
                            super(nombre, descripcion, categoria, precio, urlFoto);
                            this.garantiaMeses = garantiaMeses;
                            public int getGarantiaMeses() {
                                return garantiaMeses;
                            }

                            public void setGarantiaMeses(int garantiaMeses) {
                                this.garantiaMeses = garantiaMeses;
                            }

}